function sales(carsSold) {}

module.exports = sales;
