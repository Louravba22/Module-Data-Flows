
function exampleFunction() {
return true
}

export default exampleFunction;

